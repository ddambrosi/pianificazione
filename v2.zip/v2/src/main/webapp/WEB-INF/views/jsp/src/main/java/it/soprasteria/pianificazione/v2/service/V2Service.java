package it.soprasteria.pianificazione.v2.service;

import java.util.ArrayList;
import java.util.List;

import it.soprasteria.pianificazione.v2.bean.RecordV2Bean;

public class V2Service {

	public List<RecordV2Bean> getV2() {
		
		List<RecordV2Bean> result = new ArrayList<RecordV2Bean>();
		
		
		return result;
	}
	
	public void save(RecordV2Bean record) {
		
		
	}
	
	
}
